-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2024 at 09:52 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `updationDate`) VALUES
(1, 'admin', 'sseutm', '30-10-2022 11:42:05 AM');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `doctorSpecialization` varchar(255) DEFAULT NULL,
  `doctorId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `consultancyFees` int(11) DEFAULT NULL,
  `appointmentDate` varchar(255) DEFAULT NULL,
  `appointmentTime` varchar(255) DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT current_timestamp(),
  `userStatus` int(11) DEFAULT NULL,
  `doctorStatus` int(11) DEFAULT NULL,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `doctorSpecialization`, `doctorId`, `userId`, `consultancyFees`, `appointmentDate`, `appointmentTime`, `postingDate`, `userStatus`, `doctorStatus`, `updationDate`) VALUES
(1, 'ENT', 1, 1, 500, '2022-11-10', '12:45 PM', '2022-11-06 12:21:48', 1, 0, '2022-11-06 12:23:35'),
(2, 'ENT', 1, 2, 500, '2022-11-17', '7:00 PM', '2022-11-06 13:16:18', 1, 1, NULL),
(3, 'Dermatology', 0, 4, 0, '2024-04-24', '9:15 PM', '2024-04-26 13:17:33', 1, 1, NULL),
(4, 'Dental Care', 0, 4, 0, '2024-04-30', '8:30 PM', '2024-04-26 13:21:55', 1, 1, NULL),
(5, 'Neurologists', 0, 4, 0, '2024-05-01', '9:45 PM', '2024-04-26 13:40:02', 1, 1, NULL),
(6, 'ENT', 0, 4, 0, '2024-05-01', '10:00 PM', '2024-04-26 13:53:13', 1, 1, NULL),
(7, 'Orthopedics', 5, 4, 8000, '2024-05-01', '10:15 PM', '2024-04-26 14:28:05', 0, 1, '2024-04-27 10:21:58'),
(8, 'Pediatrics', 8, 5, 2500, '2024-05-02', '10:30 AM', '2024-04-26 14:31:00', 1, 1, NULL),
(9, 'Dermatology', 7, 4, 2000, '2024-06-20', '10:00 AM', '2024-04-26 15:27:12', 1, 1, NULL),
(10, 'Obstetrics and Gynecology', 4, 4, 10000, '2024-06-30', '10:30 PM', '2024-04-27 06:17:13', 1, 1, NULL),
(11, 'Dermatology', 7, 4, 2000, '2024-04-28', '6:30 PM', '2024-04-27 10:27:11', 1, 1, NULL),
(12, 'Dermatology', 7, 6, 2000, '2024-04-28', '6:30 PM', '2024-04-27 10:30:14', 1, 1, NULL),
(13, 'Obstetrics and Gynecology', 4, 4, 10000, '2024-04-30', '11:00 PM', '2024-04-27 15:13:08', 1, 1, NULL),
(14, 'Pediatrics', 8, 4, 2500, '2024-04-30', '11:45 PM', '2024-04-27 15:58:59', 1, 1, NULL),
(15, 'Pediatrics', 8, 4, 2500, '02-06-2024', '9:00 AM', '2024-05-01 07:13:59', 1, 1, NULL),
(16, 'Orthopedics', 5, 4, 8000, '01-05-2024', '4:15 PM', '2024-05-01 08:10:30', 1, 0, '2024-05-01 08:21:23'),
(17, 'Internal Medicine', 6, 4, 5000, '01-05-2024', '4:15 PM', '2024-05-01 08:14:32', 1, 1, NULL),
(18, 'Internal Medicine', 6, 6, 5000, '2024-05-01', '5:30 PM', '2024-05-01 09:25:20', 1, 1, NULL),
(19, 'Internal Medicine', 6, 5, 5000, '2024-05-01', '5:30 PM', '2024-05-01 09:26:08', 1, 1, NULL),
(20, 'Internal Medicine', 6, 1, 5000, '2024-05-01', '5:30 PM', '2024-05-01 09:45:12', 1, 1, NULL),
(21, 'Internal Medicine', 6, 1, 5000, '2024-05-01', '5:30 PM', '2024-05-01 09:47:13', 1, 1, NULL),
(22, 'Orthopedics', 5, 1, 8000, '2024-05-01', '6:00 PM', '2024-05-01 09:47:42', 1, 1, NULL),
(23, 'Orthopedics', 5, 1, 8000, '2024-05-01', '6:00 PM', '2024-05-01 09:47:56', 1, 1, NULL),
(24, 'Obstetrics and Gynecology', 4, 6, 10000, '2024-05-01', '6:00 PM', '2024-05-01 09:50:58', 1, 1, NULL),
(25, 'Obstetrics and Gynecology', 4, 4, 10000, '2024-05-01', '6:00 PM', '2024-05-01 09:51:39', 1, 1, NULL),
(26, 'Obstetrics and Gynecology', 4, 5, 10000, '2024-05-01', '6:00 PM', '2024-05-01 09:53:26', 1, 1, NULL),
(27, 'Orthopedics', 5, 6, 8000, '2024-05-05', '12:15 AM', '2024-05-03 16:12:51', 1, 1, NULL),
(28, 'Orthopedics', 5, 5, 8000, '2024-05-05', '12:15 AM', '2024-05-03 16:20:27', 1, 1, NULL),
(29, 'Orthopedics', 5, 5, 8000, '2024-05-05', '12:15 AM', '2024-05-03 16:29:00', 1, 1, NULL),
(30, 'Orthopedics', 5, 5, 8000, '2024-05-05', '12:15 AM', '2024-05-03 16:29:25', 1, 1, NULL),
(31, 'Obstetrics and Gynecology', 4, 5, 10000, '2024-05-08', '10:00 AM', '2024-05-03 16:30:16', 1, 1, NULL),
(32, 'Obstetrics and Gynecology', 4, 6, 10000, '2024-05-08', '10:00 AM', '2024-05-03 16:32:26', 1, 1, NULL),
(33, 'Obstetrics and Gynecology', 4, 6, 10000, '2024-05-08', '10:00 AM', '2024-05-03 16:42:05', 1, 1, NULL),
(34, 'Obstetrics and Gynecology', 4, 6, 10000, '2024-05-08', '10:00 AM', '2024-05-03 16:42:23', 1, 1, NULL),
(35, 'Obstetrics and Gynecology', 4, 6, 10000, '2024-05-10', '10:30 PM', '2024-05-03 16:43:13', 1, 1, NULL),
(36, 'Obstetrics and Gynecology', 4, 5, 10000, '2024-05-10', '10:30 PM', '2024-05-03 16:44:32', 1, 1, NULL),
(37, 'Pediatrics', 8, 6, 2500, '2024-05-10', '1:00 AM', '2024-05-03 16:55:08', 1, 1, NULL),
(38, 'Pediatrics', 8, 5, 2500, '2024-05-10', '1:00 AM', '2024-05-03 16:59:07', 1, 1, NULL),
(39, 'Internal Medicine', 6, 5, 5000, '2024-05-28', '1:15 AM', '2024-05-03 17:07:35', 1, 1, NULL),
(40, 'Internal Medicine', 6, 6, 5000, '2024-05-28', '1:15 AM', '2024-05-03 17:08:56', 1, 1, NULL),
(41, 'Obstetrics and Gynecology', 4, 5, 10000, '2024-05-30', '1:00 AM', '2024-05-03 17:16:02', 1, 1, NULL),
(42, 'Obstetrics and Gynecology', 4, 6, 10000, '2024-05-30', '1:00 AM', '2024-05-03 17:17:04', 1, 1, NULL),
(43, 'Obstetrics and Gynecology', 4, 6, 10000, '2024-05-30', '11:00 AM', '2024-05-07 15:04:43', 1, 1, NULL),
(44, 'Obstetrics and Gynecology', 4, 5, 10000, '2024-05-30', '11:00 AM', '2024-05-07 15:07:45', 1, 1, NULL),
(45, 'Orthopedics', 5, 6, 8000, '2024-05-31', '11:00 AM', '2024-05-07 15:21:09', 1, 1, NULL),
(46, 'Orthopedics', 5, 4, 8000, '2024-05-28', '10:00 AM', '2024-05-19 08:10:46', 1, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `specilization` varchar(255) DEFAULT NULL,
  `doctorName` varchar(255) DEFAULT NULL,
  `address` longtext DEFAULT NULL,
  `docFees` varchar(255) DEFAULT NULL,
  `contactno` bigint(11) DEFAULT NULL,
  `docEmail` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `specilization`, `doctorName`, `address`, `docFees`, `contactno`, `docEmail`, `password`, `creationDate`, `updationDate`) VALUES
(4, 'Obstetrics and Gynecology', 'Dr. Umar ', 'UTM JB', '10000RM', 7036315387, 'babagana@graduate.utm.my', 'e6af1a7e4e1581eda6c8df075ae34332', '2024-04-26 12:23:32', '2024-04-27 15:49:48'),
(5, 'Orthopedics', 'Dr. Edmon', 'UTM JB', '8000RM', 601161793872, 'edmon@graduate.utm.my', 'e6af1a7e4e1581eda6c8df075ae34332', '2024-04-26 14:21:37', NULL),
(6, 'Internal Medicine', 'Dr. Joseph', 'UTM KL', '5000RM', 60194048481, 'joseph@graduate.utm.my', 'e6af1a7e4e1581eda6c8df075ae34332', '2024-04-26 14:23:00', NULL),
(8, 'Pediatrics', 'Dr. Revathi', 'UTMKL', '2500RM', 919121327318, 'revathi@graduate.utm.my', 'e6af1a7e4e1581eda6c8df075ae34332', '2024-04-26 14:26:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `doctorslog`
--

CREATE TABLE `doctorslog` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT current_timestamp(),
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `doctorslog`
--

INSERT INTO `doctorslog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(20, NULL, 'gfdgdf', 0x3a3a3100000000000000000000000000, '2022-11-04 01:02:16', NULL, 0),
(21, 2, 'charudua12@test.com', 0x3a3a3100000000000000000000000000, '2022-11-06 11:59:40', '06-11-2022 05:35:18 PM', 1),
(22, 2, 'charudua12@test.com', 0x3a3a3100000000000000000000000000, '2022-11-06 12:06:37', '06-11-2022 05:36:40 PM', 1),
(23, 2, 'charudua12@test.com', 0x3a3a3100000000000000000000000000, '2022-11-06 12:08:56', '06-11-2022 05:42:53 PM', 1),
(24, 1, 'anujk123@test.com', 0x3a3a3100000000000000000000000000, '2022-11-06 12:23:18', '06-11-2022 05:53:40 PM', 1),
(25, 2, 'charudua12@test.com', 0x3a3a3100000000000000000000000000, '2022-11-06 13:16:53', '06-11-2022 06:47:07 PM', 1),
(26, 1, 'anujk123@test.com', 0x3a3a3100000000000000000000000000, '2022-11-06 13:17:33', '01-05-2024 02:20:20 PM', 1),
(27, NULL, 'babagana@graduate.utm.y', 0x3132372e302e302e3100000000000000, '2024-04-26 12:24:16', NULL, 0),
(28, NULL, 'Dr. Umar Babagana', 0x3132372e302e302e3100000000000000, '2024-04-26 12:24:42', NULL, 0),
(29, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-26 12:58:33', '26-04-2024 06:29:03 PM', 1),
(30, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-26 13:18:16', '26-04-2024 06:48:53 PM', 1),
(31, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-26 13:23:34', '26-04-2024 06:54:38 PM', 1),
(32, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-26 13:46:35', '26-04-2024 07:22:35 PM', 1),
(33, NULL, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-26 14:31:33', NULL, 0),
(34, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-26 14:31:49', '26-04-2024 08:02:08 PM', 1),
(35, 8, 'revathi@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-26 14:32:25', '26-04-2024 08:07:42 PM', 1),
(36, 8, 'revathi@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-26 15:18:18', '26-04-2024 08:49:15 PM', 1),
(37, 7, 'anthony@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-26 15:27:53', '26-04-2024 08:58:24 PM', 1),
(38, NULL, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 06:15:33', NULL, 0),
(39, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 06:16:04', '27-04-2024 11:48:15 AM', 1),
(40, NULL, 'edmond@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 10:03:23', NULL, 0),
(41, 5, 'edmon@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 10:04:18', NULL, 1),
(42, 5, 'edmon@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 10:22:50', NULL, 1),
(43, 7, 'anthony@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 10:30:54', NULL, 1),
(44, 7, 'anthony@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 10:36:33', NULL, 1),
(45, NULL, 'anthony@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 10:43:07', NULL, 0),
(46, 7, 'anthony@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 10:43:30', '27-04-2024 07:50:41 PM', 1),
(47, 7, 'anthony@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 14:25:01', '27-04-2024 07:59:04 PM', 1),
(48, NULL, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 14:29:22', NULL, 0),
(49, NULL, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 14:29:41', NULL, 0),
(50, 5, 'edmon@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 14:29:57', NULL, 1),
(51, 7, 'anthony@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 14:31:00', NULL, 1),
(52, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 14:58:01', '27-04-2024 08:50:51 PM', 1),
(53, 7, 'anthony@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 15:21:10', '27-04-2024 08:52:22 PM', 1),
(54, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 15:22:40', '27-04-2024 09:07:41 PM', 1),
(55, NULL, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 15:48:35', NULL, 0),
(56, NULL, 'babagana@graduate.utm', 0x3132372e302e302e3100000000000000, '2024-04-27 15:50:29', NULL, 0),
(57, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 15:50:57', NULL, 1),
(58, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 16:09:00', '27-04-2024 10:05:19 PM', 1),
(59, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-27 16:40:10', '27-04-2024 10:53:59 PM', 1),
(60, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-29 16:14:10', NULL, 1),
(61, 8, 'revathi@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-01 07:14:23', '01-05-2024 12:50:29 PM', 1),
(62, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-01 07:29:41', '01-05-2024 01:45:53 PM', 1),
(63, 5, 'edmon@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-01 07:56:13', NULL, 1),
(64, 5, 'edmon@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-01 08:16:27', NULL, 1),
(65, 5, 'edmon@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-01 08:20:12', NULL, 1),
(66, 6, 'joseph@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-01 08:25:25', '03-05-2024 10:38:14 PM', 1),
(67, 5, 'edmon@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-01 09:49:15', '01-05-2024 03:24:06 PM', 1),
(68, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-01 09:51:21', NULL, 1),
(69, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-01 09:54:24', '01-05-2024 03:47:12 PM', 1),
(70, 5, 'edmon@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-03 16:13:18', '19-05-2024 01:55:25 PM', 1),
(71, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-03 16:30:47', NULL, 1),
(72, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-03 16:45:25', NULL, 1),
(73, 8, 'revathi@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-03 16:58:02', NULL, 1),
(74, 8, 'revathi@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-03 17:00:43', NULL, 1),
(75, 6, 'joseph@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-03 17:08:34', '07-05-2024 08:34:57 PM', 1),
(76, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-03 17:17:30', NULL, 1),
(77, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-04 10:33:45', NULL, 1),
(78, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-07 09:12:05', NULL, 1),
(79, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-07 14:41:45', NULL, 1),
(80, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-07 15:05:24', NULL, 1),
(81, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-07 15:08:35', NULL, 1),
(82, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-10 03:24:31', NULL, 1),
(83, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-19 08:08:13', NULL, 1),
(84, NULL, 'bababgana', 0x3132372e302e302e3100000000000000, '2024-05-19 08:25:40', NULL, 0),
(85, NULL, 'babaganaa@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-19 08:30:45', NULL, 0),
(86, NULL, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-19 08:31:03', NULL, 0),
(87, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-19 08:31:58', NULL, 1),
(88, NULL, 'umar', 0x3132372e302e302e3100000000000000, '2024-05-19 09:05:34', NULL, 0),
(89, 4, 'babagana@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-19 09:06:27', '19-05-2024 02:36:43 PM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `doctorsname`
--

CREATE TABLE `doctorsname` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctorsname`
--

INSERT INTO `doctorsname` (`id`, `name`) VALUES
(1, 'Dr. Umar'),
(2, 'Dr. Edmond'),
(3, 'Dr. Joseph'),
(4, 'Dr. Anthony'),
(5, 'Dr. Revathi');

-- --------------------------------------------------------

--
-- Table structure for table `doctorspecilization`
--

CREATE TABLE `doctorspecilization` (
  `id` int(11) NOT NULL,
  `specilization` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `doctorspecilization`
--

INSERT INTO `doctorspecilization` (`id`, `specilization`, `creationDate`, `updationDate`) VALUES
(1, 'Orthopedics', '2022-10-30 18:09:46', NULL),
(2, 'Internal Medicine', '2022-10-30 18:09:57', NULL),
(3, 'Obstetrics and Gynecology', '2022-10-30 18:10:18', NULL),
(4, 'Dermatology', '2022-10-30 18:10:28', NULL),
(5, 'Pediatrics', '2022-10-30 18:10:37', NULL),
(6, 'Radiology', '2022-10-30 18:10:46', NULL),
(7, 'General Surgery', '2022-10-30 18:10:56', NULL),
(8, 'Ophthalmology', '2022-10-30 18:11:03', NULL),
(9, 'Anesthesia', '2022-10-30 18:11:15', NULL),
(10, 'Pathology', '2022-10-30 18:11:22', NULL),
(11, 'ENT', '2022-10-30 18:11:30', NULL),
(12, 'Dental Care', '2022-10-30 18:11:39', NULL),
(13, 'Dermatologists', '2022-10-30 18:12:02', NULL),
(14, 'Endocrinologists', '2022-10-30 18:12:10', NULL),
(15, 'Neurologists', '2022-10-30 18:12:30', NULL),
(22, 'ICU', '2024-05-01 07:24:19', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactus`
--

CREATE TABLE `tblcontactus` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contactno` bigint(12) DEFAULT NULL,
  `message` mediumtext DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `AdminRemark` mediumtext DEFAULT NULL,
  `LastupdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `IsRead` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblcontactus`
--

INSERT INTO `tblcontactus` (`id`, `fullname`, `email`, `contactno`, `message`, `PostingDate`, `AdminRemark`, `LastupdationDate`, `IsRead`) VALUES
(3, 'JOHN', 'john@gmail.com', 9036315387, 'You have to improved some of medical personnel are not treating patient in good manner.', '2024-04-26 15:17:07', 'Well noted', '2024-04-27 09:54:58', 1),
(4, 'Edmond', 'asied@gmail.com', 6011765432, 'Yo guys can do better', '2024-04-27 09:56:30', 'gcsaKJhL<', '2024-05-01 08:44:54', 1),
(5, 'Abaraham Lincoln ', 'abaraham@gmail.com', 9036315387, 'Your service is very slow try to improved ', '2024-05-01 07:35:33', 'Received Noted', '2024-05-01 07:36:30', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblmedicalhistory`
--

CREATE TABLE `tblmedicalhistory` (
  `ID` int(10) NOT NULL,
  `PatientID` int(10) DEFAULT NULL,
  `BloodPressure` varchar(200) DEFAULT NULL,
  `BloodSugar` varchar(200) NOT NULL,
  `Weight` varchar(100) DEFAULT NULL,
  `Temperature` varchar(200) DEFAULT NULL,
  `MedicalPres` mediumtext DEFAULT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblmedicalhistory`
--

INSERT INTO `tblmedicalhistory` (`ID`, `PatientID`, `BloodPressure`, `BloodSugar`, `Weight`, `Temperature`, `MedicalPres`, `CreationDate`) VALUES
(1, 1, '80/120', '120', '85', '98', 'Test', '2022-11-06 13:19:41'),
(2, 2, '0+', 'NO', '1.7', '225', 'Panadol Extra to take 2 times far day morning and evening ', '2024-04-26 13:50:13'),
(3, 3, 'high', 'high', 'too big', 'high', 'stop eating', '2024-04-27 10:18:58'),
(4, 4, '200', '150', '1.6', '100', 'Take your medication tow times far day (i.e) morning and evening.', '2024-04-27 10:39:17'),
(5, 4, 'g', '24', '45', '434', 'eafds', '2024-04-27 13:06:23'),
(6, 4, '45', 'gfh', 'fghhhj', 'gfhh', 'This is testing', '2024-04-27 13:09:06'),
(7, 4, '23', '20', '176', '200', '21244', '2024-04-27 13:13:18'),
(8, 4, '233', '23', '120', '40', '566', '2024-04-27 13:14:00'),
(9, 4, '12', '20', '20', '30', '190', '2024-04-27 13:17:29'),
(10, 4, '19', '20', '21', '76', '32', '2024-04-27 13:19:14'),
(11, 4, '234', '24', '34', '44', '55', '2024-04-27 13:21:02'),
(12, 4, '34', '12', '22', '11', '22', '2024-04-27 13:23:18'),
(13, 4, '35', '55', '44', '55', '567', '2024-04-27 13:26:42'),
(14, 4, '78', '79', '130', '120', '55', '2024-04-27 13:30:20'),
(15, 4, '120', '201', '12', '11', '67', '2024-04-27 13:42:33'),
(16, 4, '456', '45', '345', '643', '6436', '2024-04-27 13:49:30'),
(17, 4, '56', '40', '11', '201', '445', '2024-04-27 13:57:31'),
(18, 4, '23', '44', '5', '45', 'THIS IS TESTING', '2024-04-27 13:58:22'),
(19, 4, '546', '7457', '77', '74', '457', '2024-04-27 14:03:29'),
(20, 4, '5', '56', '6', '6', '6', '2024-04-27 14:14:15'),
(21, 5, '20', '12', '190', '76', 'Take the drugs two times far day (i.e) morning and evening', '2024-04-27 15:15:38'),
(22, 6, '34', '37', '56', '300', '56', '2024-04-27 15:31:51'),
(23, 7, '87', '87', '877', '78', '787', '2024-04-27 15:36:18'),
(24, 8, '45', '444', '455', '67', '77', '2024-04-27 16:33:58'),
(25, 9, '56', '6', '60', '56', '66', '2024-04-27 16:41:25'),
(26, 10, '12', '50', '11', '22', '34', '2024-04-29 16:20:12'),
(27, 11, '25', '50', '180', '12', 'Take your drugs two times far day (i.e morning and afternoon) ', '2024-05-01 07:19:09'),
(28, 13, '79', '23', '67', '56', 'Reduce your sugar intake\r\n', '2024-05-01 08:37:32'),
(29, 10, '10', '15', '170', '66', 'Take the drugs two times far day regularly.', '2024-05-04 10:34:52'),
(30, 10, '12', '50', '60', '45', 'Take your two times far day ', '2024-05-07 09:13:41'),
(31, 10, '59', '7', '89', '70', 'Take your drugs to times far day morning and afternoon thank you', '2024-05-07 14:52:49');

-- --------------------------------------------------------

--
-- Table structure for table `tblpage`
--

CREATE TABLE `tblpage` (
  `ID` int(10) NOT NULL,
  `PageType` varchar(200) DEFAULT NULL,
  `PageTitle` varchar(200) DEFAULT NULL,
  `PageDescription` mediumtext DEFAULT NULL,
  `Email` varchar(120) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `UpdationDate` timestamp NULL DEFAULT current_timestamp(),
  `OpenningTime` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblpage`
--

INSERT INTO `tblpage` (`ID`, `PageType`, `PageTitle`, `PageDescription`, `Email`, `MobileNumber`, `UpdationDate`, `OpenningTime`) VALUES
(1, 'aboutus', 'About Us', '<ul style=\"padding: 0px; margin-right: 0px; margin-bottom: 1.313em; margin-left: 1.655em;\" times=\"\" new=\"\" roman\";=\"\" font-size:=\"\" 14px;=\"\" text-align:=\"\" center;=\"\" background-color:=\"\" rgb(255,=\"\" 246,=\"\" 246);\"=\"\"><li style=\"text-align: left;\"><font color=\"#000000\">The Hospital Management System (HMS) is designed for Any Hospital to replace their existing manual, paper based system. The new system is to control the following information; patient information, room availability, staff and operating room schedules, and patient invoices. These services are to be provided in an efficient, cost effective manner, with the goal of reducing the time and resources currently required for such tasks.</font></li><li style=\"text-align: left;\"><font color=\"#000000\">A significant part of the operation of any hospital involves the acquisition, management and timely retrieval of great volumes of information. This information typically involves; patient personal information and medical history, staff information, room and ward scheduling, staff scheduling, operating theater scheduling and various facilities waiting lists. All of this information must be managed in an efficient and cost wise fashion so that an institution\'s resources may be effectively utilized HMS will automate the management of the hospital making it more efficient and error free. It aims at standardizing data, consolidating data ensuring data integrity and reducing inconsistencies.&nbsp;</font></li></ul>', NULL, NULL, '2020-05-20 07:21:52', NULL),
(2, 'contactus', 'Contact Details', 'D-204, Hole Town South West, Delhi-110096,India', 'info@gmail.com', 1122334455, '2020-05-20 07:24:07', '9 am To 8 Pm');

-- --------------------------------------------------------

--
-- Table structure for table `tblpatient`
--

CREATE TABLE `tblpatient` (
  `ID` int(10) NOT NULL,
  `Docid` int(10) DEFAULT NULL,
  `PatientName` varchar(200) DEFAULT NULL,
  `PatientContno` bigint(10) DEFAULT NULL,
  `PatientEmail` varchar(200) DEFAULT NULL,
  `PatientGender` varchar(50) DEFAULT NULL,
  `PatientAdd` mediumtext DEFAULT NULL,
  `PatientAge` int(10) DEFAULT NULL,
  `PatientMedhis` mediumtext DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblpatient`
--

INSERT INTO `tblpatient` (`ID`, `Docid`, `PatientName`, `PatientContno`, `PatientEmail`, `PatientGender`, `PatientAdd`, `PatientAge`, `PatientMedhis`, `CreationDate`, `UpdationDate`) VALUES
(10, 4, 'Zara Bukar Jidda', 806087192, 'zarabukar@yahoo.com', 'female', 'UTM KL', 15, 'NIl', '2024-04-29 16:15:11', NULL),
(12, 1, 'Josephine', 601161793, 'josephine@gmail.com', 'female', 'kkdjskczlkz', 16, 'Asthma', '2024-05-01 08:02:50', NULL),
(13, 6, 'ISIYAKA MUSA', 806087193, 'isiyaisa@gmail.com', 'Male', 'KLG CAMPUS RESIDENCE', 18, 'diabetes', '2024-05-01 08:33:53', '2024-05-01 08:34:51'),
(14, 4, 'MARYAM BABAGANA', 8060871923, 'maryama@gmail.com', 'female', 'UTM KL', 21, 'NIL', '2024-05-10 04:07:35', NULL),
(15, 4, 'JAAFAR', 9060871922, 'jaafar@yahoo.com', 'male', 'Damaturu, Nigeria', 25, 'NIL', '2024-05-10 04:19:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT current_timestamp(),
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(1, 1, 'johndoe12@test.com', 0x3a3a3100000000000000000000000000, '2022-11-06 12:14:11', NULL, 1),
(2, 1, 'johndoe12@test.com', 0x3a3a3100000000000000000000000000, '2022-11-06 12:21:20', '26-04-2024 08:43:38 PM', 1),
(3, NULL, 'amitk@gmail.com', 0x3a3a3100000000000000000000000000, '2022-11-06 13:15:43', NULL, 0),
(4, 2, 'amitk@gmail.com', 0x3a3a3100000000000000000000000000, '2022-11-06 13:15:58', '06-11-2022 06:50:46 PM', 1),
(5, NULL, 'johnabraham', 0x3132372e302e302e3100000000000000, '2024-04-26 12:27:43', NULL, 0),
(6, NULL, 'johnabraham@gmail.com', 0x3132372e302e302e3100000000000000, '2024-04-26 12:55:55', NULL, 0),
(7, NULL, 'johnabraham@gmail.com', 0x3132372e302e302e3100000000000000, '2024-04-26 12:56:02', NULL, 0),
(8, NULL, 'johnabraham@gmail.com', 0x3132372e302e302e3100000000000000, '2024-04-26 12:56:15', NULL, 0),
(9, NULL, 'johnabraham@gmail.com', 0x3132372e302e302e3100000000000000, '2024-04-26 12:57:03', NULL, 0),
(10, 4, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-04-26 13:00:23', '26-04-2024 06:47:57 PM', 1),
(11, NULL, 'isiyaku@gmail.com', 0x3132372e302e302e3100000000000000, '2024-04-26 13:19:11', NULL, 0),
(12, 4, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-04-26 13:20:56', '26-04-2024 06:53:15 PM', 1),
(13, 4, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-04-26 13:39:14', '26-04-2024 07:16:15 PM', 1),
(14, 4, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-04-26 13:52:52', '26-04-2024 07:48:13 PM', 1),
(15, NULL, 'isiya', 0x3132372e302e302e3100000000000000, '2024-04-26 14:27:22', NULL, 0),
(16, 4, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-04-26 14:27:35', NULL, 1),
(17, 5, 'saiibrahim@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-04-26 14:30:22', '01-05-2024 01:47:26 PM', 1),
(18, 4, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-04-26 15:26:22', '26-04-2024 08:57:24 PM', 1),
(19, 4, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-04-27 06:16:32', NULL, 1),
(20, 4, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-04-27 10:20:58', NULL, 1),
(21, 4, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-04-27 10:24:04', '27-04-2024 03:57:28 PM', 1),
(22, NULL, 'zarabukar', 0x3132372e302e302e3100000000000000, '2024-04-27 10:29:35', NULL, 0),
(23, 6, 'zarabukar@gmail.com', 0x3132372e302e302e3100000000000000, '2024-04-27 10:29:55', '27-04-2024 04:00:28 PM', 1),
(24, 6, 'zarabukar@gmail.com', 0x3132372e302e302e3100000000000000, '2024-04-27 10:34:32', NULL, 1),
(25, 6, 'zarabukar@gmail.com', 0x3132372e302e302e3100000000000000, '2024-04-27 10:39:54', '01-05-2024 02:17:55 PM', 1),
(26, 4, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-04-27 15:11:46', NULL, 1),
(27, 4, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-04-27 15:39:50', '27-04-2024 09:38:25 PM', 1),
(28, 4, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-01 07:12:35', NULL, 1),
(29, 4, 'isiya@GMAIL.COM', 0x3132372e302e302e3100000000000000, '2024-05-01 07:29:08', '01-05-2024 01:03:43 PM', 1),
(30, NULL, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-01 07:41:20', NULL, 0),
(31, NULL, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-01 07:43:07', NULL, 0),
(32, 4, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-01 07:43:33', '01-05-2024 01:13:38 PM', 1),
(33, 4, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-01 08:09:54', NULL, 1),
(34, 4, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-01 08:21:57', '19-05-2024 01:42:21 PM', 1),
(35, NULL, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-01 08:48:10', NULL, 0),
(36, NULL, 'edmon@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-01 09:02:22', NULL, 0),
(37, NULL, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-01 09:02:31', NULL, 0),
(38, NULL, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-01 09:11:16', NULL, 0),
(39, NULL, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-01 09:11:27', NULL, 0),
(40, NULL, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-01 09:11:49', NULL, 0),
(41, 6, 'zarabukar@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-01 09:12:57', '01-05-2024 02:55:27 PM', 1),
(42, 5, 'saiibrahim@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-01 09:25:50', NULL, 1),
(43, 6, 'zarabukar@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-01 09:50:33', NULL, 1),
(44, 5, 'saiibrahim@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-01 09:53:11', NULL, 1),
(45, NULL, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-03 16:09:17', NULL, 0),
(46, NULL, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-03 16:09:31', NULL, 0),
(47, 6, 'zarabukar@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-03 16:09:52', NULL, 1),
(48, NULL, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-03 16:14:25', NULL, 0),
(49, NULL, 'joseph@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-03 16:14:34', NULL, 0),
(50, NULL, 'ibrahimsai@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-03 16:15:06', NULL, 0),
(51, NULL, 'isiyaisa@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-03 16:18:43', NULL, 0),
(52, NULL, 'isiyaisa@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-03 16:19:10', NULL, 0),
(53, 5, 'saiibrahim@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-03 16:19:43', NULL, 1),
(54, 6, 'zarabukar@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-03 16:32:03', '03-05-2024 10:13:31 PM', 1),
(55, 5, 'saiibrahim@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-03 16:43:45', NULL, 1),
(56, 6, 'zarabukar@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-03 16:53:07', NULL, 1),
(57, 5, 'saiibrahim@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-03 16:58:48', NULL, 1),
(58, 5, 'saiibrahim@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-03 17:06:52', '03-05-2024 10:37:42 PM', 1),
(59, 6, 'zarabukar@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-03 17:08:00', NULL, 1),
(60, 5, 'saiibrahim@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-03 17:15:34', '03-05-2024 10:46:15 PM', 1),
(61, 6, 'zarabukar@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-03 17:16:43', NULL, 1),
(62, NULL, 'isiyaisa@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-04 10:30:58', NULL, 0),
(63, 6, 'zarabukar@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-04 10:31:13', NULL, 1),
(64, 6, 'zarabukar@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-04 10:36:07', NULL, 1),
(65, NULL, 'zarabukar@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-07 08:56:32', NULL, 0),
(66, 6, 'zarabukar@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-07 08:56:46', '07-05-2024 02:31:56 PM', 1),
(67, 7, 'algurawy2018@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-07 09:03:16', '07-05-2024 02:36:07 PM', 1),
(68, 6, 'zarabukar@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-07 15:02:20', NULL, 1),
(69, NULL, 'isiyaisa@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-07 15:06:17', NULL, 0),
(70, NULL, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-07 15:06:31', NULL, 0),
(71, NULL, 'joseph@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-07 15:06:47', NULL, 0),
(72, 5, 'saiibrahim@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-07 15:07:23', NULL, 1),
(73, 6, 'zarabukar@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-07 15:17:28', '07-05-2024 08:51:18 PM', 1),
(74, 5, 'saiibrahim@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-07 15:21:48', NULL, 1),
(75, NULL, 'joseph@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-14 18:10:58', NULL, 0),
(76, NULL, 'zara@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-19 06:47:18', NULL, 0),
(77, NULL, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-19 06:47:29', NULL, 0),
(78, NULL, 'joseph@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-19 06:47:42', NULL, 0),
(79, NULL, 'zarahbukar@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-19 06:48:07', NULL, 0),
(80, NULL, 'zarabukar@yahoo.com', 0x3132372e302e302e3100000000000000, '2024-05-19 06:49:41', NULL, 0),
(81, NULL, 'umar@yahoo.com', 0x3132372e302e302e3100000000000000, '2024-05-19 07:56:37', NULL, 0),
(82, NULL, 'umar', 0x3132372e302e302e3100000000000000, '2024-05-19 07:59:00', NULL, 0),
(83, NULL, 'umar', 0x3132372e302e302e3100000000000000, '2024-05-19 07:59:20', NULL, 0),
(84, NULL, 'zarabukar@yahoo.com', 0x3132372e302e302e3100000000000000, '2024-05-19 08:01:43', NULL, 0),
(85, 6, 'zarabukar@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-19 08:02:35', NULL, 1),
(86, NULL, 'isiya@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-19 08:12:40', NULL, 0),
(87, 5, 'saiibrahim@graduate.utm.my', 0x3132372e302e302e3100000000000000, '2024-05-19 08:12:59', NULL, 1),
(88, 6, 'zarabukar@gmail.com', 0x3132372e302e302e3100000000000000, '2024-05-19 09:21:09', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `address` longtext DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `regDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullName`, `address`, `city`, `gender`, `email`, `password`, `regDate`, `updationDate`) VALUES
(5, 'IBRAHIM USMAN', 'UTM JL', 'KL', 'male', 'saiibrahim@graduate.utm.my', 'e10adc3949ba59abbe56e057f20f883e', '2024-04-26 14:30:00', NULL),
(6, 'Zarah Bukar Jidda', 'Nguru, Yobe State, Nigeria', 'Nguru', 'female', 'zarabukar@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2024-04-27 10:29:05', NULL),
(7, 'Umar Musa', 'UTM JB', 'JB', 'male', 'algurawy2018@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2024-05-07 09:02:46', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorslog`
--
ALTER TABLE `doctorslog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorsname`
--
ALTER TABLE `doctorsname`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorspecilization`
--
ALTER TABLE `doctorspecilization`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactus`
--
ALTER TABLE `tblcontactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblmedicalhistory`
--
ALTER TABLE `tblmedicalhistory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblpage`
--
ALTER TABLE `tblpage`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblpatient`
--
ALTER TABLE `tblpatient`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `doctorslog`
--
ALTER TABLE `doctorslog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `doctorsname`
--
ALTER TABLE `doctorsname`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `doctorspecilization`
--
ALTER TABLE `doctorspecilization`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tblcontactus`
--
ALTER TABLE `tblcontactus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblmedicalhistory`
--
ALTER TABLE `tblmedicalhistory`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `tblpage`
--
ALTER TABLE `tblpage`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblpatient`
--
ALTER TABLE `tblpatient`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
